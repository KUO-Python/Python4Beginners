# Religion Survey

This directory contains the data behind the story [When Does Praying In Public Make Others Uncomfortable?](http://fivethirtyeight.com/features/when-does-praying-in-public-make-others-uncomfortable)

Using a SurveyMonkey poll, conducted between July 29 and August 1, 2016, we asked 661 respondents [questions about public displays of religion](https://espnfivethirtyeight.files.wordpress.com/2016/09/surveymonkey_82631483.pdf).
