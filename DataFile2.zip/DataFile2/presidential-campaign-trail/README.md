# Presidential Campaign Trail

This folder contains data behind the story [The Last 10 Weeks Of 2016 Campaign Stops In One Handy Gif](http://fivethirtyeight.com/features/the-last-10-weeks-of-2016-campaign-stops-in-one-handy-gif/).

Header | Definition
---|---------
`date` | The date of the event
`location` | The location of the event
`lat` | Latitude of the event location
`lng` | Longitude of the event location

Sources:
* [hillaryspeeches.com](https://hillaryspeeches.com/)
* [conservativedailynews.com](http://www.conservativedailynews.com/)
