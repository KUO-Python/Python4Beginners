# Undefeated Boxers

This directory contains the data behind the story [Mayweather Is Defined By The Zero Next To His Name](https://fivethirtyeight.com/features/mayweather-is-defined-by-the-zero-next-to-his-name/).

Data on boxing matches of undefeated boxers from [http://boxrec.com/](http://boxrec.com/).

Header | Definition
-------|------------
name | Boxer's Name
date | Date of the match
wins | Number of cumulative wins for the boxer including the match at the specified date
url | URL with boxer's record
