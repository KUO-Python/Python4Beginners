# Trump News

This folder contains the data behind the story [How Trump Hacked The Media](http://fivethirtyeight.com/features/how-donald-trump-hacked-the-media/).

File | Description
---|---------
`trump_news_data.csv` | Records the lead story of [Memeorandum](http://www.memeorandum.com/) each day at noon, since June 16, 2015. If the story is about Donald Trump, the story is classified as either polls, vs. GOP, comments or other.