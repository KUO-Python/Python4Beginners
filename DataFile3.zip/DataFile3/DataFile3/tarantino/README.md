# Tarantino

This folder contains data behind the story [A Complete Catalog Of Every Time Someone Cursed Or Bled Out In A Quentin Tarantino Movie](http://fivethirtyeight.com/features/complete-catalog-curses-deaths-quentin-tarantino-films).

Header | Definition
---|---------
`movie` | Film title
`type` | Whether the event was a profane word or a death
`word` | The specific profane word, if the event was a word
`minutes_in` | The number of minutes into the film the event occurred


Source: Author’s tally