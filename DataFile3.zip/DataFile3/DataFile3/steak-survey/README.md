# Steak Survey

This folder contains data behind the stories:
* [How Americans Like Their Steak](https://fivethirtyeight.com/features/how-americans-like-their-steak/).
* [How Americans Order Their Steak](https://fivethirtyeight.com/features/how-americans-order-their-steak/)

