---
files:
  - https://projects.fivethirtyeight.com/march-madness-api/2018/fivethirtyeight_ncaa_forecasts.csv
---
# March Madness 2018

This file contains links to the data behind our [2018 March Madness Predictions](https://projects.fivethirtyeight.com/2018-march-madness-predictions/).

`fivethirtyeight_ncaa_forecasts.csv` contains power ratings for each team and the chance of each team reaching every round of the tournament. It includes men's and women's forecasts, with one forecast for each day of the tournament.
