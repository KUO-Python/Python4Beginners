# Male Flight Attendants

This folder contains the data behind the story [Dear Mona, How Many Flight Attendants Are Men?](http://fivethirtyeight.com/datalab/dear-mona-how-many-flight-attendants-are-men/)

`male-flight-attendants.tsv` contains the percentage of U.S. employees that are male in 320 different job categories.

Source: [IPUMS](https://usa.ipums.org/usa/), 2012

