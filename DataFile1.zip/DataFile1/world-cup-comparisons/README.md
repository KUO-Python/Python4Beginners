---
files:
  - https://projects.fivethirtyeight.com/soccer-api/international/2018/world_cup_comparisons.csv
---
# World Cup Comparisons

This file contains links to the data behind [50 Years Of World Cup Doppelgangers](https://projects.fivethirtyeight.com/world-cup-comparisons/).

`world_cup_comparisons.csv` contains all historical players and their associated z-score for each of the 16 metrics.
