# Repeated Phrases GOP

This folder contains data behind the story [These Are The Phrases Each GOP Candidate Repeats Most](http://fivethirtyeight.com/features/these-are-the-phrases-each-gop-candidate-repeats-most).

File | Description
---|---------
`gop_debate_all.txt` | Plain text transcription of all Republican primary debates from the August 6, 2015 Fox News debate in Cleveland through the March 3, 2016 Fox News debate in Detroit
`robopol2.py` | Python script that conducts a term frequency–inverse document frequency (tf-idf) analysis of the text in `gop_debate_all.txt`
