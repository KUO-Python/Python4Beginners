# Infrastructure Jobs

This folder contains data behind the story [Using Infrastructure Jobs as a Measuring Stick For State-Level Spending](https://fivethirtyeight.com/features/using-infrastructure-jobs-as-a-measuring-stick-for-state-level-spending/).