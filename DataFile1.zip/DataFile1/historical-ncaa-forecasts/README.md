# NCAA Bracket

This folder contains data behind the story [The NCAA Bracket: Checking Our Work](https://fivethirtyeight.com/datalab/the-ncaa-bracket-checking-our-work).