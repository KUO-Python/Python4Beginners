# Chess Transfers

This folder contains data behind the story [American Chess Is Great Again](https://fivethirtyeight.com/features/american-chess-is-great-again/).

Headers | Description
--------|-------------
url | Source Data
ID | Player ID
Federation | Player's new federation
Form.Fed | Player's former federation
Transfer Date | Date of transfer

Data was collected from [FIDE](https://ratings.fide.com/fedchange.phtml).
