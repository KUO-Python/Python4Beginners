---
files:
  - https://projects.fivethirtyeight.com/soccer-api/international/2018/wc_matches.csv
  - https://projects.fivethirtyeight.com/soccer-api/international/2018/wc_forecasts.csv
---
# World Cup 2018

This file contains links to the data behind our [2018 World Cup Predictions](https://projects.fivethirtyeight.com/2018-world-cup-predictions/).

`wc_matches.csv` contains match-by-match projections.

`wc_forecasts.csv` contains our tournament forecasts.
