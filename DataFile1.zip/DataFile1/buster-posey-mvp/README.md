# Buster Posey MVP

This folder contains the code behind the story [Buster Posey’s Pitch Framing Makes Him A Potential MVP](http://fivethirtyeight.com/features/buster-poseys-pitch-framing-makes-him-a-potential-mvp/).

File | Description
---|---------
`baseball_imgcap_for_release.py` | Captures and crops images from a computer screen every .05 seconds.
`catcher_framing_capture.R` | Reads the images into R and calculates the number of pixels changed between successive images.

Source: [Bloomberg Video](https://www.bsports.com/pro#.Vbo2RvlVhBc)
