---
files:
  - https://projects.fivethirtyeight.com/congress-tracker-data/csv/averages.csv
  - https://projects.fivethirtyeight.com/congress-tracker-data/csv/vote_predictions.csv
---
# Congress Trump Score

This file contains links to the data behind [Tracking Congress In The Age Of Trump](https://projects.fivethirtyeight.com/congress-trump-score/).
